var chicktest = 0;
var itemchosen = "";
var one = document.getElementById("G1");
var two = document.getElementById("G2");
var choice1;
var switcha = 0;
$('#frame_2').css('display', 'none');
$('#frame_1').css('display', 'block');
//document.getElementById('gender-male-label').onclick = GFG_click; 
//document.getElementById('gender-female-label').onclick = GFG_click; 



function GFG_click(elm1) {
  choice1 = elm1.id;
  $('#stepper2trigger1').css('background', 'transparent url(img/step-line-checked.png) no-repeat left');

  //var gender=this.id ;
  //  two.innerHTML = "Button clicked, id = " + gender ;                   
}

var three = document.getElementById("G3");
var four = document.getElementById("G4");
var five = document.getElementById("G5");
var six = document.getElementById("G6");
var seven = document.getElementById("G7");
var choice2;

function GFG_click2(elm2) {
  choice2 = elm2.id;
  $('#stepper2trigger2').css('background', 'transparent url(img/step-line-checked.png) no-repeat left');
  $('#stepper2trigger2').css('background-size', '100% auto');
  //var activity=this.id ;
  //  three.innerHTML = "Button clicked, id = " + activity ;

}
var eight = document.getElementById("G8");
var nine = document.getElementById("G9");
var ten = document.getElementById("G10");
var eleven = document.getElementById("G11");
var twelve = document.getElementById("G12");
var thirteen = document.getElementById("G13");
choice3;

function GFG_click3(elm3) {

  choice3 = elm3.id;
  if (itemchosen != elm3.id) {
    chicktest = 0;
  }


  if (chicktest == 0) {
    chicktest = 1;
    $(elm3).parent().parent().addClass("checked");
    itemchosen = elm3.id;

  }
  else {
    chicktest = 0;
    $(elm3).parent().parent().removeClass("checked");

  }


}

var forteen = document.getElementById("G14");
var fifteen = document.getElementById("G15");
var sixteen = document.getElementById("G16");
var seventeen = document.getElementById("G17");
var eighteen = document.getElementById("G18");
var ninetten = document.getElementById("G19");
choice4;
function GFG_click4(elm4) {
  choice4 = elm4.id;

  if (itemchosen != elm4.id) {
    chicktest = 0;
  }


  if (chicktest == 0) {
    chicktest = 1;
    $(elm4).parent().parent().addClass("checked");
    itemchosen = elm4.id;

  }
  else {
    chicktest = 0;
    $(elm4).parent().parent().removeClass("checked");

  }

}

var twenty = document.getElementById("G20");
var twentyone = document.getElementById("G21");
var twentywo = document.getElementById("G22");
var twentythree = document.getElementById("G23");
var twentyfour = document.getElementById("G24");
var twentyfive = document.getElementById("G25");
choice5;
function GFG_click5(elm5) {
  choice5 = elm5.id;



  if (itemchosen != elm5.id) {
    chicktest = 0;
  }


  if (chicktest == 0) {
    chicktest = 1;
    $(elm5).parent().parent().addClass("checked");
    itemchosen = elm5.id;

  }
  else {
    chicktest = 0;
    $(elm5).parent().parent().removeClass("checked");

  }

}

var caloriess = "";
function calories() {


  if (switcha == 0) {

    if ($("#input-weight").val() <= 45) {
      caloriess = "1100-1200";
      
    }

    else if  ($("#input-weight").val() > 45 && $("#input-weight").val() <= 50) {
      caloriess = "1300-1400";
    }

    else if ($("#input-weight").val() > 50 && $("#input-weight").val() <= 55) {
      caloriess = "1400-1500";
    }

    else if ($("#input-weight").val() > 55 && $("#input-weight").val() <= 60) {
      caloriess = "1600-1700";
    }

    else if  ($("#input-weight").val() > 60 && $("#input-weight").val() <= 65) {
      caloriess = "1700-1800";
    }

    else if  ($("#input-weight").val() > 65 && $("#input-weight").val() <= 70) {
      caloriess = "1800-1900";
    }

    else if  ($("#input-weight").val() > 70 && $("#input-weight").val() <= 75) {
      caloriess = "2000-2100";
    }

    else if  ($("#input-weight").val() > 75 && $("#input-weight").val() <= 80) {
      caloriess = "2100-2200";
    }

    else if  ($("#input-weight").val() > 80 && $("#input-weight").val() <= 85) {
      caloriess = "2200-2300";
    }

    else if  ($("#input-weight").val() > 85 && $("#input-weight").val() <= 90) {
      caloriess = "2400-2500";
    }

    else if  ($("#input-weight").val() > 90 && $("#input-weight").val() <= 95) {
      caloriess = "2500-2600";
    }

    else if  ($("#input-weight").val() > 95 && $("#input-weight").val() <= 100) {
      caloriess = "2600-2700";
    }

    else if  ($("#input-weight").val() > 100 && $("#input-weight").val() <= 105) {
      caloriess = "2800-2900";
    }

    else {
      caloriess = "2900-3000"
    }
  
  }
  if (switcha == 1) {

    if ($("#input-weight_i").val() <= 45) {
      caloriess = "1100-1200";
    }

    else if ($("#input-weight_i").val() > 45 && $("#input-weight_i").val() <= 50) {
      caloriess = "1300-1400";
    }

    else if  ($("#input-weight_i").val() > 50 && $("#input-weight_i").val() <= 55) {
      caloriess = "1400-1500";
    }

    else if  ($("#input-weight_i").val() > 55 && $("#input-weight_i").val() <= 60) {
      caloriess = "1600-1700";
    }

    else if  ($("#input-weight_i").val() > 60 && $("#input-weight_i").val() <= 65) {
      caloriess = "1700-1800";
    }

    else if  ($("#input-weight_i").val() > 65 && $("#input-weight_i").val() <= 70) {
      caloriess = "1800-1900";
    }

    else if  ($("#input-weight_i").val() > 70 && $("#input-weight_i").val() <= 75) {
      caloriess = "2000-2100";
    }

    else if  ($("#input-weight_i").val() > 75 && $("#input-weight_i").val() <= 80) {
      caloriess = "2100-2200";
    }

    else if  ($("#input-weight_i").val() > 80 && $("#input-weight_i").val() <= 85) {
      caloriess = "2200-2300";
    }

    else if  ($("#input-weight_i").val() > 85 && $("#input-weight_i").val() <= 93) {
      caloriess = "2400-2500";
    }

    else if  ($("#input-weight_i").val() >= 94 && $("#input-weight_i").val() <= 97) {
      caloriess = "2500-2600";
    }

    else if  ($("#input-weight_i").val() > 99 && $("#input-weight_i").val() <= 100) {
      caloriess = "2600-2700";
    }

    else if  ($("#input-weight_i").val() > 100 && $("#input-weight_i").val() <= 105) {
      caloriess = "2800-2900";
    }

    else {
      caloriess = "2900-3000"
    }
    
  }
 
}

var resultf = 0;
function calculatefats() {
  var [before, after] = caloriess.split("-")
  var f1 = parseInt(before);



  if (f1 <= 1100) {
    resultf = "80-100";
  }

  else if (f1 > 1100 && f1 <= 1300) {
    resultf = "100-120";
  }

  else if (f1 > 1300 && f1 <= 1400) {
    resultf = "80-100";
  }

  else if (f1 > 1400 && f1 <= 1600) {
    resultf = "120-140";
  }

  else if (f1 > 1600 && f1 <= 1700) {
    resultf = "130-150";
  }

  else if(f1 > 1700 && f1 <= 1800) {
    resultf = "140-160";
  }

  else if (f1 > 1800 && f1 <= 2000) {
    resultf = "150-170";
  }

  else if (f1 > 2000 && f1 <= 2100) {
    resultf = "160-180";
  }

  else if (f1 > 2100 && f1 <= 2200) {
    resultf = "170-190";
  }

  else if (f1 > 2200 && f1 <= 2400) {
    resultf = "180-200";
  }

  else if (f1 > 2400 && f1 <= 2500) {
    resultf = "190-210";
  }

  else if (f1 > 2500 && f1 <= 2600) {
    resultf = "200-220";
  }

  else if (f1 > 2600 && f1 <= 2800) {
    resultf = "210-230";
  }

  else if (f1 > 2800 && f1 <= 2900) {
    resultf = "220-240";
  }
  else {
    resultf = "230-260"
  }




}
var prot = 0;
var resultp = 0;
function calculateproteins() {
  var [before, after] = resultf.split("-")
  prot = parseInt(before);
  resultp = (prot-40) + "-" + (prot-20);

}


function display() {


  $('#cals1').html(caloriess);
  $('#cals2').html(caloriess);

  $('#prots1').html(resultp);
  $('#prots2').html(resultp);

  $('#fats1').html(resultf + "g");
  $('#fats2').html(resultf + "g");
}
function myFunction() {

  calculateBmi();
  calories();

  calculateWater();
  calculatefats();
  calculateCarbs();
  calculateproteins()
  display();
  achieweight();
  actlevel();
  $('#frame_1').css('display', 'none');
  $('#frame_2').css('display', 'block');

  var res;
}
function actlevel(){ 
if (choice2=="activity-level-12"){
  res="Low";
}
if (choice2=="activity-level-13"){
  res="Moderate";
}
if (choice2=="activity-level-14"){
  res="Moderate"
}
if (choice2=="activity-level-15"){
  res="High"
}
if (choice2=="activity-level-16"){
  res="Athlete"
}
$('#level').html(res)            
}

var result;
var finalBmi = 1;
function calculateBmi() {


  if (switcha == 0) {

    var finalBmi = ($('#input-weight').val() / (($('#input-height').val() / 100) * ($('#input-height').val() / 100))).toFixed(1);

    if (finalBmi < 18.5) {
      var result = "Underweight";
    };
    if (finalBmi >= 18.5 && finalBmi < 25) {
      result = "Normal";
    }
    if (finalBmi >= 25) {
      result = "Overweight";
    }
  }

  if (switcha == 1) {
    totinches = parseInt($('#input-height_i_ft').val()) * 12 + parseInt($('#input-height_i_inh').val());

    var finalBmi = ($('#input-weight_i').val() * 703 / (totinches * totinches)).toFixed(1);

    if (finalBmi < 18.5) {
      var result = "Underweight";
    }
    if (finalBmi >= 18.5 && finalBmi < 25) {
      result = "Normal";
    }
    if (finalBmi >= 25) {
      result = "Overweight";
    }
  }

  $('#bmi_centered').html(finalBmi);
  $('#bmi_text').html(result);
  if ($('#input-target_weight').val() && switcha == 0) {
    $('.lgrn-gradient-text').html($('#input-target_weight').val() + "  Kg");
  }
  else if ($('#input-target_weight_i').val() && switcha == 1) {
    $('.lgrn-gradient-text').html($('#input-target_weight_i').val() + "  lbs");
  }

}

function calculateWater() {

  if (switcha == 1) {

    if ($('#input-age_i').val() < 30) {
      result1 = (($('#input-weight_i').val() * 0.54) / 28.3);
      result2 = result1.toFixed(1);

    }
    if ($('#input-age_i').val() >= 30) {
      result1 = (($('#input-weight_i').val() * 0.47) / 28.3);
      rsult2 = result1.toFixed(1);
    }
  }

  if (switcha == 0) {
    if ($('#input-age').val() < 30) {
      result1 = (($('#input-weight').val() * 1.2) / 28.3);
      result2 = result1.toFixed(1);
    }
    if ($('#input-age').val() >= 30) {
      result1 = (($('#input-weight').val() * 1.05) / 28.3);
      result2 = result1.toFixed(1);
    }
  }

  $('.water').html(result2 + 'L');
}
var resulta=0;
function achieweight(){
 
if (switcha==0){
  if($('#input-weight').val() >=45){
  resulta= ($('#input-weight').val() - 5) ;
}
else if($('#input-weight').val() <45){ 
  resulta=40; 
}

}

 if (switcha==1){
  if($('#input-weight_i').val()>= 100){
resulta= (($('#input-weight_i').val()*0.45) - 5);} 
if($('#input-weight_i').val() < 100){
  resulta=40;
}}
resulta=resulta.toFixed(0);

$('#achievable_weight').html(resulta+" Kg")
 
}
function calculateCarbs() {

  if ($('#input-age').val() < 30) {
    carbs = "10-20";

  }
  if ($('#input-age').val() >= 30 && $('#input-age').val() < 50) {
    carbs = "20-30";

  }
  if ($('#input-age').val() >= 50 && $('#input-age').val() <= 100) {
    carbs = "30-40";
  }


  //for imperial
  if ($('#input-age_i').val() < 30) {
    carbs = "10-20";

  }
  if ($('#input-age_i').val() >= 30 && $('#input-age_i').val() < 50) {
    carbs = "20-30";

  }
  if ($('#input-age_i').val() >= 50 && $('#input-age_i').val() <= 100) {
    carbs = "30-40";
  }

}
$('#info1').css('display', 'block');
$('#help1').css('display', 'none');
var shd1 = 0;
function showhide1() {

  if (shd1 == 0) {

    $('#info1').css('display', 'none');
    $('#help1').css('display', 'block');
    shd1 = 1;
  } else {
    $('#info1').css('display', 'block');
    $('#help1').css('display', 'none');
    shd1 = 0;
  }

}


$('#info2').css('display', 'block');
$('#help2').css('display', 'none');
var shd2 = 0;
function showhide2() {

  if (shd2 == 0) {

    $('#info2').css('display', 'none');
    $('#help2').css('display', 'block');
    shd2 = 1;
  } else {
    $('#info2').css('display', 'block');
    $('#help2').css('display', 'none');
    shd2 = 0;
  }

}

$('#info3').css('display', 'block');
$('#help3').css('display', 'none');
var shd3 = 0;
function showhide3() {

  if (shd3 == 0) {

    $('#info3').css('display', 'none');
    $('#help3').css('display', 'block');
    shd3 = 1;
  } else {
    $('#info3').css('display', 'block');
    $('#help3').css('display', 'none');
    shd3 = 0;
  }
}

$('#info4').css('display', 'block');
$('#help4').css('display', 'none');
var shd4 = 0;
function showhide4() {

  if (shd4 == 0) {

    $('#info4').css('display', 'none');
    $('#help4').css('display', 'block');
    shd4 = 1;
  } else {
    $('#info4').css('display', 'block');
    $('#help4').css('display', 'none');
    shd4 = 0;
  }
}

$('#info5').css('display', 'block');
$('#help5').css('display', 'none');
var shd5 = 0;
function showhide5() {

  if (shd5 == 0) {

    $('#info5').css('display', 'none');
    $('#help5').css('display', 'block');
    shd5 = 1;
  } else {
    $('#info5').css('display', 'block');
    $('#help5').css('display', 'none');
    shd5 = 0;
  }
}

$('#info6').css('display', 'block');
$('#help6').css('display', 'none');
var shd6 = 0;
function showhide6() {

  if (shd6 == 0) {

    $('#info6').css('display', 'none');
    $('#help6').css('display', 'block');
    shd6 = 1;
  } else {
    $('#info6').css('display', 'block');
    $('#help6').css('display', 'none');
    shd6 = 0;
  }
}

$('#info7').css('display', 'block');
$('#help7').css('display', 'none');
var shd7 = 0;
function showhide7() {

  if (shd7 == 0) {

    $('#info7').css('display', 'none');
    $('#help7').css('display', 'block');
    shd7 = 1;
  } else {
    $('#info7').css('display', 'block');
    $('#help7').css('display', 'none');
    shd7 = 0;
  }
}

$('#info8').css('display', 'block');
$('#help8').css('display', 'none');
var shd8 = 0;
function showhide8() {

  if (shd8 == 0) {

    $('#info8').css('display', 'none');
    $('#help8').css('display', 'block');
    shd8 = 1;
  } else {
    $('#info8').css('display', 'block');
    $('#help8').css('display', 'none');
    shd8 = 0;
  }
}

function main() {
  if (switcha == 0) {
    if ($('#input-age').val().length === 0 || $('#input-height').val().length === 0 || $('#input-weight').val().length === 0 || $('#input-target_weight').val().length === 0) {
      alert("Please fill all the details");
    }
    else {
      myFunction();

    }
  }

  if (switcha == 1) {
    if ($('#input-age_i').val().length === 0 || $('#input-height_i_ft').val().length === 0 || $('#input-height_i_inh').val().length === 0 || $('#input-weight_i').val() == "" || $('#input-target_weight_i').val().length === 0) {
      alert("Please fill all the details");
    }
    else {
      myFunction();
    }
  }

}
function checkstep3() {

  $('#stepper2trigger3').css('background', 'transparent url(img/step-line-checked.png) no-repeat left');
  $('#stepper2trigger3').css('background-size', '100% auto');

}
function checkstep4() {

  $('#stepper2trigger4').css('background', 'transparent url(img/step-line-checked.png) no-repeat left');
  $('#stepper2trigger4').css('background-size', '100% auto');

}
function checkstep5() {

  $('#stepper2trigger5').css('background', 'transparent url(img/step-line-checked.png) no-repeat left');
  $('#stepper2trigger5').css('background-size', '100% auto');

}
function checkstep6() {

  $('#stepper2trigger6').css('background', 'transparent url(img/step-line-checked.png) no-repeat left');
  $('#stepper2trigger6').css('background-size', '100% auto');

}
 
var one = document.getElementById("G1"); 
var two= document.getElementById("G2"); 

  
document.getElementById('gender-male-label').onclick = GFG_click; 
document.getElementById('gender-female-label').onclick = GFG_click; 


  
function GFG_click(clicked1) { 
var gender=this.id ;
    two.innerHTML = "Button clicked, id = " + gender ;                   
}
var three = document.getElementById("G3"); 
var four= document.getElementById("G4");   
var five= document.getElementById("G5"); 
var six= document.getElementById("G6"); 
var seven= document.getElementById("G7"); 
 

  document.getElementById('3').onclick = GFG_click2;
document.getElementById('4').onclick = GFG_click2;
document.getElementById('5').onclick = GFG_click2;
document.getElementById('6').onclick = GFG_click2;
document.getElementById('7').onclick = GFG_click2;
          
function GFG_click2(clicked2) {
  
var activity=this.id ;
   three.innerHTML = "Button clicked, id = " + activity ;

}

            var eight = document.getElementById("G8"); 
            var nine= document.getElementById("G9");   
            var ten= document.getElementById("G10"); 
            var eleven= document.getElementById("G11"); 
            var twelve= document.getElementById("G12"); 
            var thirteen= document.getElementById("G13");
            
              document.getElementById('8').onclick = GFG_click3;
            document.getElementById('9').onclick = GFG_click3;
            document.getElementById('10').onclick = GFG_click3;
            document.getElementById('11').onclick = GFG_click3;
            document.getElementById('12').onclick = GFG_click3;
            document.getElementById('13').onclick = GFG_click3;

            function GFG_click3(clicked3) {
              
 var  meat=this.id ;
                eight.innerHTML = "Button clicked, id = " + meat ;
            }

            
            var forteen = document.getElementById("14"); 
            var fifteen= document.getElementById("G15");   
            var sixteen= document.getElementById("G16"); 
            var seventeen= document.getElementById("G17"); 
            var eighteen= document.getElementById("G18"); 
            var ninteen= document.getElementById("G19");
            
              document.getElementById('14').onclick = GFG_click4;
            document.getElementById('15').onclick = GFG_click4;
            document.getElementById('16').onclick = GFG_click4;
            document.getElementById('17').onclick = GFG_click4;
            document.getElementById('18').onclick = GFG_click4;
            document.getElementById('19').onclick = GFG_click4;

            function GFG_click4(clicked4) {
              
 var  veggies=this.id ;
                fifteen.innerHTML = "Button clicked, id = " + veggies;
            }

            var twenty = document.getElementById("G20"); 
var twentyone= document.getElementById("G21");   
var twentytwo = document.getElementById("G22"); 
var twentythree= document.getElementById("G23"); 
var twentyfour= document.getElementById("G24"); 
var twentyfive= document.getElementById("G25");

  document.getElementById('20').onclick = GFG_click5;
document.getElementById('21').onclick = GFG_click5;
document.getElementById('22').onclick = GFG_click5;
document.getElementById('23').onclick = GFG_click5;
document.getElementById('24').onclick = GFG_click5;
document.getElementById('25').onclick = GFG_click5;

function GFG_click5(clicked5) {
  
var otherFood=this.id ;
   twentyone.innerHTML = "Button clicked, id = " + otherFood ;
}


var twentysix = document.getElementById("G26"); 
var twentyseven= document.getElementById("G27");   
 

  document.getElementById('26').onclick = GFG_click6;
document.getElementById('27').onclick = GFG_click6;
 

function GFG_click6(clicked6) {
  
var measurement=this.id ;
   twentysix.innerHTML = "Button clicked, id = " + measurement ;
}
function somefunc(event) {
  var $this = $(this),
    method = $this.data('method'),
    message = $this.data('confirm'),
    form = $this.data('form');

  if (method === undefined && message === undefined && form === undefined) {
    return true;
  }

  if (message !== undefined && message !== false && message !== '') {
    $.proxy(pub.confirm, this)(message, function() {
      pub.handleAction($this, event);
    });
  } else {
    pub.handleAction($this, event);
  }
  event.stopImmediatePropagation();
  return false;
}
